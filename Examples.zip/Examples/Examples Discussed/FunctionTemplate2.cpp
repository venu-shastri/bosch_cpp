#include<iostream>
using namespace std;

//An example on generic function or template, supporting a single unknown datatype.

template<typename T> void Add(T x, T y)  //generic function
{
	cout <<"sum:" << x+y << endl;
}

//Specialize the above function template for CHAR TYPE
template<> void Add(char x, char y)  // type-specific or non-generic function
{
	cout <<"cannot add characters..." << endl;
}
//---consumer code-----

int main()
{
	Add(10,20);
	Add(45.12f, 67.32f);
	Add(99.92, 33.9234);
	//----------------------
	Add('r','w');
	return 0;
}