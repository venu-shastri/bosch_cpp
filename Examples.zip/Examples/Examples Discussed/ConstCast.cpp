#include<iostream>
using namespace std;

//An example on const_cast

class CA
{
private:
	int a, b;
public:
	CA(int x = 0, int y = 0) :a(x), b(y) { }
	void input()   //non-const method
	{
		cout << "enter 2 nos..." << endl;
		cin >> this->a >> this->b;
	}
	//const method
	void print() const { cout << "a:" << a << ",b=" << b << endl; }
};

//****consumer code**********
int main()
{
	const CA* p1 = new(nothrow) CA(10, 20);
	p1->print();   //const object's will only call const methods
	//p1->input();  
	//Remove the constness on the object
	CA* p2 = const_cast<CA*>(p1);
	p2->input();
	p2->print();
	return 0;
}