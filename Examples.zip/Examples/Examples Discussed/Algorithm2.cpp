#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;


bool Ascending(int &x, int &y)   //is called a predicate function
{
	if(x < y)
		return true;
	else
		return false;
}


bool Descending(int &x, int &y)   //is a predicate function
{
	if(x > y)
		return true;
	else
		return false;
}

int main()
{
	vector<int> v1 = {34,12,67,87,90,43,2,9,82};
	//sort(v1.begin(), v1.end(),Ascending);
    
	sort(v1.begin(), v1.end(),Descending);
	cout <<"After sorting..." << endl;
	vector<int>::iterator itr = v1.begin();
	while(itr != v1.end())
	{
		cout << *itr <<",";
		itr ++;
	}
	cout << endl;
	return 0;
}