#include<iostream>
using namespace std;

template<typename T1, typename T2> void Add(T1 x, T2 y)
{
	cout <<"sum:" << x+y << endl;
}


//---consumer code----
int main()
{
	Add(300, 45.12f);
	Add(67.21, 400);
	//The above generic function is also a candidate for homogenous input types
	Add(10,20);
	return 0;
}