#include<iostream>
using namespace std;
/*  -- An example on conversion function
* A function whose name is a data-type.
* Conversion functions do not take any known formal parameters
* They must and should return a value, whose type will be 'function-name'
* We are not supposed to explicitly state the return-type of the function
*/

class CA
{
private:
	int a, b;
public:
	CA() :a(0), b(0) { }
	explicit CA(int x) :a(x), b(x) { }
	CA(int x, int y) :a(x), b(y) { }
	operator int();
	operator double();
};

CA::operator int()
{
	//cout << __FUNCDNAME__ << endl;
	cout << "operator int called" << endl;
	return a + b;
}

CA::operator double()
{
	//cout << __FUNCDNAME__ << endl;
	cout << "operator double called" << endl;
	return a + b;     // return (double) a+b;
}
//***consumer code****
int main()
{
	CA obj1(10, 20);
	int x;
	//approach -1
	x = obj1;         // x = obj1.operator int();
	//approach-2
	x = (int)obj1;     // x = obj1.operator int();
	//approach-3
	cout << (int)obj1 << endl;    // cout << obj1.operator int() << endl;
	cout << "************************" << endl;
	double y;
	y = (double) obj1;
	return 0;
}
