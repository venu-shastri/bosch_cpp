#include<iostream>
using namespace std;

int a =100;  //global variable
class CA
{
private:
	int a;  //data member 'a'
public:
	void print()
	{
		int a = 300;  //local 'a'
		//code for printing all the 3 'a's
		cout <<"global variable a:" << ::a << endl;
		cout <<"class data member a:" << this->a << endl;
		cout <<"local variable a:" << a << endl;
	}
};

int main()
{
	CA obj1;
	obj1.print();
	return 0;
}
