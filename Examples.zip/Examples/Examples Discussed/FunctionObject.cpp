#include<iostream>
using namespace std;

//Example on function object and functor
typedef void(*FP)(int, int);

class Function
{
private:
	FP fp;         //An object encapsulating a function pointer is a function object
public:
	Function(FP ff) :fp(ff) { }
	void Call(int x, int y)
	{
		(*fp)(x, y);
	}
	void operator()(int x, int y)   //FUNCTION OPERATOR OVERLOADED - functor
	{
		(*fp)(x, y);
	}
	void Set(FP ff)     // void(*ff)(int, int) = &Diff;
	{
		this->fp = ff;
	}
};

//----------------------------
void Add(int x, int y)
{
	cout << "Add called, sum=" << x + y << endl;
}
void Diff(int x, int y)
{
	cout << "Diff called, sum =" << x - y << endl;
}
//----------------------------
//****consumer code******

int main()
{
	Function f1(&Add);
	//f1.Call(10, 20);
	f1(10, 20);        // f1.operator()(10,20);
	cout << "*************" << endl;
	f1.Set(&Diff);
	f1(30, 10);
	return 0;
}