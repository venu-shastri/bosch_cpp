#include<iostream>
using namespace std;
//An example on assignment operator overloading

class CA
{
private:
	int a,b;
public:
	CA(int=0,int=0);   // CA(), CA(int), CA(int, int);
	void print() const;
	CA& operator =(const CA&);
};

CA::CA(int x, int y):a(x),b(y){ }
void CA::print() const{cout <<"a:" << a <<"b:" << b << endl; }
CA& CA::operator =(const CA &x)
{
	cout <<"operator = called" << endl;
	this->a = x.a;
	this->b = x.b;
	return *this;
}
//******consumer code*****
int main()
{
	CA obj1(10,20), obj2;
	CA result;
	//result = obj1;         // result.operator =(obj1);
	result = obj2 = obj1;    // result.operator =(obj2.operator =(obj1));
	result.print();
	obj2.print();
	return 0;
}