#include<iostream>
using namespace std;
//An example malloc/free for class objects..
/*
* prefer malloc/free over new/delete for primitives and C structs.
* prefer new/delete over malloc/free for class objects.
*/

class CA
{
private:
	int a, b;
public:
	CA();
	CA(int);
	CA(int, int);
	explicit CA(const CA&);
	~CA();
	void input();
	void print() const;
	CA* operator ->();
};

//place the function definitions outside the class body
CA::CA() :a(0), b(0)  //initialization list
{
	cout << "CA default constructor..." << this << endl;
}

CA::CA(int x) : a(x), b(x)    //CONVERSION CONSTRUCTOR
{
	cout << "CA one arg. constructor..." << this << endl;
}

CA::CA(int x, int y) : a(x), b(y)
{
	cout << "CA two arg. constructor..." << this << endl;
}
//define the copy constructor
CA::CA(const CA& x) : a(x.a), b(x.b)
{
	cout << "CA copy constructor..." << endl;
}

CA::~CA() { cout << "CA destructor..." << this << endl; }

void CA::input()
{
	cout << "enter 2 inputs..." << endl;
	cin >> this->a >> this->b;
}

void CA::print() const
{
	cout << "a:" << this->a << ",b:" << this->b << endl;
}

CA* CA::operator ->()
{
	cout <<"operator -> called" << endl;
	return this;
}

//***consumer code****
int main()
{
	//create an array of 5 CA instances on the HEAP
	//CA* p = new(nothrow) CA[5];
	/*
	- In order to provide parameter(s) to the individual object's of the array,
	  we use the modern C++11 syntax, called 'brace initialization syntax'
	- Enable the command line option '-std=c++11'
	*/
	CA* p = new(nothrow) CA[5]{{},{100},{20,30},{},{500}};
	//business on the individual objects part of the array
	p[0].print();
	p[1]->print();    // (p[1].operator ->())->print();
	//...
	//delete the array of object's pointed to by 'p'
	delete [] p;
	
	return 0;
}