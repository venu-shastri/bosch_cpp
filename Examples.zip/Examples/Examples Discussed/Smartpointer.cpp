#include<iostream>
using namespace std;

/* 
* An example on Smartpointer class
* Whose instances though value types, pretend or act as pointer types...
*/

class CA //assumed to be memory expensive
{
private:
	int a, b;
public:
	CA(int x = 0, int y = 0) :a(x), b(y) { cout << "CA constructor" << endl; }
	~CA() { cout << "CA destructor" << endl; }
	void print() const { cout << "CA-print, a:" << a << ",b:" << b << endl; }
};

//*** Wrapper class, that manages CA instances on the HEAP automatically for the class consumer *****
class CB
{
private:
	CA* p;    //PIMPL  --> Pointer Implementation model  [CB contains CA, CB HAS-A CA]
public:
	CB(int x = 0, int y = 0)
	{
		p = new(nothrow) CA(x, y);      //RAII - Resource Acquisition Is Initialization
	}
	~CB()
	{
		delete p;
	}
	void print() const
	{
		p->print();
	}
	//custom copy constructor - DEEP COPY
	CB(const CB& x)
	{
		p = new(nothrow) CA(*(x.p));   //will call CA copy constructor if any...
	}
	//custom assignment function - DEEP ASSIGNMENT
	CB& operator =(CB& x)
	{
		*(this->p) = *(x.p);  // will call CA assignment function if any...
		return *this;
	}

	//Smartpointer implementation....
	CA* operator &()
	{
		cout << "operator &() called" << endl;
		return p;
	}
	CA* operator ->()
	{
		cout << "operator ->() called" << endl;
		return p;
	}
	CA& operator *()
	{
		cout << "operator *() called" << endl;
		return *p;
	}
};

//*****class consumer*****
int main()
{
	CB obj1(10, 20);
	CA* q = &obj1;     // CA* q = obj1.operator &();
	q->print();
	cout << "************" << endl;
	obj1->print();      // (obj1.operator ->())->print();
	cout << "************" << endl;
	(*obj1).print();    // (obj1.operator *()).print();
	return 0;
}