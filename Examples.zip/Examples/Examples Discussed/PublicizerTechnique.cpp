#include<iostream>
using namespace std;

//an example on publicizer technique or vertical access technique
//It generally serves 2 purposes
//	- Expose any hidden member (or)
//	- Hide any exposed member

class CA
{
public:
	void fun(){cout <<"CA fun() called" << endl;}
	void fun(int x){cout <<"CA fun(int x) called" <<endl;}
	
};

class CB:public CA
{
public:
	/*
	Any attempt to OVERLOAD a base class member function in a derived class, will
	lead to the derived class member function HIDING the base methods...
	- For we do not have OVERLOAD RESOLUTION across classes.
	*/
	//-- PUBLICIZER TECHNIQUE, Expose the BASE hidden members in the DERIVED
	using CA::fun;
	void fun(double x){cout <<"CB- fun(double) called" << endl;}
};
//consumer code
int main()
{
	CB obj1;
	obj1.fun();
	obj1.fun(100);
	obj1.fun(56.12);
	return 0;
}

