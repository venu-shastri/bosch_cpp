#include<iostream>
using namespace std;
#pragma pack(1)
//An example on hybrid inheritance model - Also called Dreaded Diamond

class CA
{
public:
	int a;
};

class CB : virtual public CA   
{
public:
	int b;
};

class CC : virtual public CA
{
public:
	int c;
};

class CD :public CB, public CC
{
public:
	int d;
};

//***consumer code****
int main()
{
	cout << "size of CD:" << sizeof(CD) << endl;
	CD obj1;
	obj1.a = 100;
	return 0;
}
