#include<iostream>
using namespace std;

//usage of the extended qualifier 'const' with a pointer variable

int main()
{
	//   ELEMENT-1
	int a=100;
	//   ELEMENT-2
	int b=200;
	//   ELEMENT-3
	const int* const p = &a;     // 'p' is a Pointer to a READ-ONLY integer, const by himself.
	
	//Operations permitted on ELEMENT-3  'p'
	cout << *p << endl;    // 1. It's address can be read
	
	
	//Operation that is NOT permitted on ELEMENT-3 'p'
	//p = &b;           // 2. It's address content cannot be modified 
	//*p = 300;         // 2. Trying to modify the value pointed to by 'p' (Write), not allowed
	return 0;
}