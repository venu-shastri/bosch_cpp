#include<iostream>
using namespace std;

class MemoryHandler
{
private:
	int* p;
public:
	MemoryHandler() :p(NULL) { }
	MemoryHandler(int* q) :p(q) { }
	~MemoryHandler()
	{
		if (p != NULL)
			delete p;
	}
	void print() const { cout << "value pointed to by p is:" << *p << endl; }
	
	int* Get() { return p; }
	
	MemoryHandler* operator ->()
	{
		return this;
	}
	
	operator bool()
	{
		if(p)
			return true;
		else
			return false;
	}
};


//****consumer code*****
int main()
{
	MemoryHandler mem1(new(nothrow)int(200));
	/*
	if(mem1.Get() != NULL)
	{
	  mem1->print();
	}
	else
	{
		cout <<"Not a valid instance" << endl;
	}
	
	cout << "*************" << endl;
	MemoryHandler mem2;
	
	if(mem2.Get() != NULL)
	{
		  mem2->print();
	}
	else
	{
		cout <<"Not a valid instance" << endl;
	}
	*/
	if(mem1)     // if(mem1.operator bool())
	{
		mem1->print();
	}
	else
	{
		cout <<"not a valid instance" << endl;
	}
	if(mem2)
	{
		mem2->print();
	}
	else
	{
		cout <<"not a valid instance" << endl;
	}
	return 0;
}