#include<iostream>
using namespace std;

//Difference between 'struct' and 'class'

//struct CA
class CA
{
private:
	int a,b;
public:
	void input()
	{
		cout <<"enter 2 nos..." << endl;
		cin >> a >> b;
	}
	
	void print()
	{
		cout <<"a:" << a <<",b:" << b << endl;
	}
};

//--- consumer code----
int main()
{
	cout <<"size of CA object:" << sizeof(CA) << endl;
	CA obj1;
	obj1.input();
	obj1.print();
	//obj1.a =100;
	//obj1.b =200;
	return 0;
}
