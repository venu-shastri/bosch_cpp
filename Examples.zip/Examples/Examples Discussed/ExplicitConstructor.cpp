#include<iostream>
using namespace std;

//An example on one arg. constructor(s) and explicit qualifier
//One arg. constructors whose formal parameter type is other than class type are candidates 
//for 'explicit' qualification, as it prevents implicit conversions.
class CA
{
private:
	int a,b;
public:
	CA();
	explicit CA(int);
	CA(int, int);
	CA(CA&);
	~CA();
	void input();
	void print();
};

//place the function definitions outside the class scope...
CA::CA():a(0),b(0)   //initialization list
{
	cout <<"CA default constructor called" << this << endl;
}
//Constructors that take a single parameter as input are also called CONVERSION constructors.
CA::CA(int x):a(x),b(x)  
{
	cout <<"CA one arg. constructor" << this<< endl;
}
CA::CA(int x, int y):a(x),b(y)
{
	cout <<"CA two arg. constructor" << this<< endl;
}
CA::~CA(){cout <<"CA destructor" << this << endl; }

CA::CA(CA &x):a(x.a),b(x.b)
{ cout <<"CA copy constructor" << endl; }

void CA::input()          // void input(CA* const this)
{
	cout <<"enter 2 nos..." << endl;
	cin >> this->a >> this->b;
}

void CA::print()           // void print(CA* const this)
{
	cout <<"a:" << this->a <<",b:" << this->b << endl;
}
//--- consumer code----
int main()
{
	CA obj1;
	//assign the object with a value
	int x = 100;
	cout <<"*** assigning int *********" << endl;
	obj1 = x;        // obj1 = CA(x);
	cout <<"************" << endl;
	cout <<"-------------" << endl;
	return 0;
}



