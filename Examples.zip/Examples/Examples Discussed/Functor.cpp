#include<iostream>
using namespace std;


//An example on functor [function operator overloading] - simple DEMO

class CA
{
public:
	void operator()()
	{
		cout <<"function operator - FUNCTOR called" << endl;
	}
};

//****consumer code****
int main()
{
	CA obj1;
	obj1();    // obj1.operator()();
	return 0;
}