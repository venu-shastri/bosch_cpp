#include<iostream>
using namespace std;

/* An example on SHALLOW copy
* - A problem context, where depending upon the compiler synthesized copy constructor and assignment function
* - is a very bad-idea.
*/

class CA //assumed to be memory expensive
{
private:
	int a, b;
public:
	CA(int x = 0, int y = 0) :a(x), b(y) { cout << "CA constructor" << endl; }
	~CA() { cout << "CA destructor" << endl; }
	void print() const { cout << "CA-print, a:" << a << ",b:" << b << endl; }
};

//*** Wrapper class, that manages CA instances on the HEAP automatically for the class consumer *****
class CB
{
private:
	CA* p;    //PIMPL  --> Pointer Implementation model  [CB contains CA, CB HAS-A CA]
public:
	CB(int x = 0, int y = 0)
	{
		p = new(nothrow) CA(x, y);      //RAII - Resource Acquisition Is Initialization
	}
	~CB()
	{
		delete p;
	}
	void print() const
	{
		p->print();
	}
};

//*****class consumer*****
int main()
{
	CB obj1(10, 20);
	obj1.print();
	//CB obj2(30, 40);
	CB obj2(obj1);
	obj2.print();
	return 0;
}


