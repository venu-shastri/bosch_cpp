#include<iostream>
using namespace std;
//An example on unary operator overloading

class CA
{
private:
	int a,b;
public:
	CA(int=0,int=0);   // CA(), CA(int), CA(int, int);
	void print() const;
	CA& operator =(const CA&);
	CA& operator ++();
	CA operator ++(int);
};

CA::CA(int x, int y):a(x),b(y){ }
void CA::print() const{cout <<"a:" << a <<"b:" << b << endl; }
CA& CA::operator =(const CA &x)
{
	cout <<"operator = called" << endl;
	this->a = x.a;
	this->b = x.b;
	return *this;
}

CA& CA::operator ++()
{
	cout <<"Operator ++ prefix" << endl;
	++ this->a;
	++ this->b;
	return *this;
}
CA CA::operator ++(int)
{
	cout <<"Operator ++ postfix" << endl;
	CA temp(*this);  //back-up the old-value prior to increment
	this->a++;
	this->b++;
	return temp;  //return the old value prior to increment
}
//******consumer code*****
int main()
{
	CA obj1(10,20), obj2(10,20);
	CA prefix, postfix;
	prefix = ++ obj1;              // prefix.operator =(obj1.operator ++());
	obj1.print();
	prefix.print();
	cout <<"---------------" << endl;
	postfix = obj2++;           // postfix.operator =(obj2.operator ++(int));
	obj2.print();
	postfix.print();
	return 0;
}