#include<iostream>
using namespace std;

//Design a class such that only HEAP objects are allowed, and no STACK instances

class CA
{
private:
	int a, b;
	//place the constructor under private
	CA() :a(0), b(0) { cout << "CA default constructor..." << endl; }
public:
	~CA() { cout << "CA destructor" << endl; }
	static CA* CreateHeapInstance()
	{
		return new CA;
	}
};


//---class consumer********
int main()
{
	CA obj1;   //stack object
	//CA* p = new CA;
	//CA* p1 = CA::CreateHeapInstance();
	//delete p1;
	//...
	//CA* p2 = CA::CreateHeapInstance();
	//delete p2;
	return 0;
}