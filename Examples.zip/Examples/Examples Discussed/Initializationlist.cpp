#include<iostream>
using namespace std;

//Prefer initialization over assigment, as it is more efficient
//When a data member of a class is qualified to be 'const', then initialization is compulsory
class CA
{
private:
	int a;
	const int b;
public:
	CA();
	CA(int);
	CA(int, int);
	~CA();
	void input();
	void print();
};

//place the function definitions outside the class scope...
CA::CA():a(0),b(0)   //initialization list
{
	cout <<"CA default constructor called" << this << endl;
}
CA::CA(int x):a(x),b(x)
{
	cout <<"CA one arg. constructor" << this<< endl;
}
CA::CA(int x, int y):a(x),b(y)
{
	cout <<"CA two arg. constructor" << this<< endl;
}
CA::~CA(){cout <<"CA destructor" << this << endl; }

void CA::input()          // void input(CA* const this)
{
	cout <<"enter 2 nos..." << endl;
	//cin >> this->a >> this->b;
}

void CA::print()           // void print(CA* const this)
{
	cout <<"a:" << this->a <<",b:" << this->b << endl;
}
//--- consumer code----
int main()
{
	CA obj1,obj2(100),obj3(30,40);
	
	obj1.print();       // CA::print(&obj1);
	obj2.print();
	obj3.print();
	return 0;
}
