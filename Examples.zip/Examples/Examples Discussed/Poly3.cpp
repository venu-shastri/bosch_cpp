#include<iostream>
using namespace std;
#pragma pack(1)

/*
	- We introduce to a new class, whose purpose is to only act as a BASE kind. As such
	  we do not have any intentions of creating an object of this type.
	- Creating an instance of this class shall not permitted as it is supposed to be a 
      Generalized class.
	- This generialized base class is also supposed to serve as a broad frame-work for
      the derived ones.
*/
class shape   //ABSTRACT class
{
protected:
	//void *vfptr;  //an invisible pointer field added by the compiler
public:
	//virtual member function - OVER-RIDABLE method
	virtual void draw()=0;   //PURE VIRTUAL FUNCTION
	virtual ~shape(){ }
};

class circle:public shape    // circle IS-A shape
{
private:
	int radius;
public:
	circle(int x = 0):/* shape(), vfptr(&circle::VFTABLE),    */radius(x) 
	{ cout << "Circle constructor" << endl; }
	//OVER-RIDING method
	 void draw() { cout << "circle drawn" << endl; }
	 ~circle() { cout << "Circle destructor" << endl; }
};

class rectangle :public shape
{
private:
	int length, breadth;
public:
	rectangle(int x = 0, int y = 0):/* shape(), vfptr(&rectangle::VFTABLE),  */length(x), breadth(y) 
	{ cout << "rectangle constructor" << endl; }
	void draw() { cout << "rectangle drawn" << endl; }
	~rectangle() { cout << "rectangle destructor" << endl; }
};

class triangle :public shape
{
private:
	int base, height;
public:
	triangle(int x = 0, int y = 0) :base(x), height(y) { cout << "triangle constructor" << endl; }
	void draw() { cout << "triangle drawn" << endl; }
	~triangle() { cout << "triangle destructor" << endl; }
};

class polygon:public shape
{
public:
	polygon(){cout <<"polygon constructor" << endl; }
	~polygon(){cout <<"polygon destructor" << endl; }
	void draw(){cout <<"polygon drawn" << endl; }
};

void graphics(shape*);

int main()
{
	//shape* p = new(nothrow) shape;
	cout << "size of circle object " << sizeof(circle) << endl;
	cout << "size of rectangle object " << sizeof(rectangle) << endl;
	cout << "size of triangle object " << sizeof(triangle) << endl;
	circle* c = new(nothrow) circle;
	graphics(c);
	cout << "-----------------------" << endl;
	rectangle* r = new(nothrow) rectangle;
	graphics(r);
	cout << "-----------------------" << endl;
	triangle* t = new(nothrow) triangle;
	graphics(t);
	cout << "-----------------------" << endl;
	polygon* p = new(nothrow) polygon;
	graphics(p);
	return 0;
}

void graphics(shape* p)   //ADHERING TO OPEN-CLOSED PRINCIPLE
{
	p->draw();
	//...
	delete p;
}



