#include<iostream>
using namespace std;

//An example function pointers to global functions.

//PROGRAMMER-1
void Add(int x, int y)
{
	cout << "Add called, sum=" << x + y << endl;
}
void Diff(int x, int y)
{
	cout << "Diff called, sum =" << x - y << endl;
}

//PROGRAMMER-2
void compute(void(*ff)(int, int), int x, int y)
{
	cout << "compute business started...." << endl;
	//choice of business here is 'compute' consumers choice
	//--------------------
	(*ff)(x, y);    // HOOK or a CALLBACK
	//--------------------
	cout << "compute business completed...." << endl;
}

//---PROGRAMMER-3------
int main()
{
	//Approach-1
	void(*fp)(int, int) = &Add;
	compute(fp, 10, 20);
	cout << "*******************" << endl;
	//Approach-2
	compute(&Diff, 40, 10);
	return 0;
}