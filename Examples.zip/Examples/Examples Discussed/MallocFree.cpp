#include<iostream>
using namespace std;
//An example malloc/free for class objects..
/*
* prefer malloc/free over new/delete for primitives and C structs.
* prefer new/delete over malloc/free for class objects.
*/

class CA
{
private:
	int a, b;
public:
	CA();
	explicit CA(int);
	CA(int, int);
	explicit CA(const CA&);
	~CA();
	void input();
	void print() const;
};

//place the function definitions outside the class body
CA::CA() :a(0), b(0)  //initialization list
{
	cout << "CA default constructor..." << this << endl;
}

CA::CA(int x) : a(x), b(x)    //CONVERSION CONSTRUCTOR
{
	cout << "CA one arg. constructor..." << this << endl;
}

CA::CA(int x, int y) : a(x), b(y)
{
	cout << "CA two arg. constructor..." << this << endl;
}
//define the copy constructor
CA::CA(const CA& x) : a(x.a), b(x.b)
{
	cout << "CA copy constructor..." << endl;
}

CA::~CA() { cout << "CA destructor..." << this << endl; }

void CA::input()
{
	cout << "enter 2 inputs..." << endl;
	cin >> this->a >> this->b;
}

void CA::print() const
{
	cout << "a:" << this->a << ",b:" << this->b << endl;
}

//***consumer code****
int main()
{
	CA* p = (CA*)malloc(sizeof(CA));
	if (p == NULL)
	{
		cout << "allocation failed..." << endl;
		exit(1);
	}
	p->print();
	free(p);

	return 0;
}