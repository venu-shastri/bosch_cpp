#include<iostream>
using namespace std;

//Design a class such that only STACK objects are allowed, and no HEAP instances

class CA
{
private:
	int a, b;
	//Overload the 'new' & 'delete' operator function under private
	void* operator new(size_t size);
	void* operator new[](size_t size);
	void operator delete(void* ptr);
	void operator delete[](void* ptr);

public:
	CA() :a(0), b(0) { cout << "CA default constructor..." << endl; }
	~CA() { cout << "CA destructor" << endl; }
};


//---class consumer********
int main()
{
	CA obj1;   //stack object
	CA* p = new CA;
	//delete p;
	return 0;
}