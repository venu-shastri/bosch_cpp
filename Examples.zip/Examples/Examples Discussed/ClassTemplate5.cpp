#include<iostream>
using namespace std;

//Generic class supporting multiple typenames...

class flute
{
public:
	void play() { cout << "playing flute..." << endl; }
};
class drums
{
public:
	void play() { cout << "playing drums..." << endl; }
};
class piano
{
public:
	void play() { cout << "playing piano..." << endl; }
};

template<typename T1, typename T2, typename T3> class Compose
{
private:
	T1 obj1;
	T2 obj2;
	T3 obj3;
public:
	void compose_music();
};

template<typename T1, typename T2, typename T3> void Compose<T1, T2, T3>::compose_music()
{
	obj1.play();
	obj2.play();
	obj3.play();
}

//****consumer code*************
int main()
{
	Compose<drums, flute, piano> music1;
	music1.compose_music();
	cout << "----------------" << endl;
	Compose<drums, drums, flute> music2;
	music2.compose_music();
	cout << "-----Solo instrument-----------" << endl;
	Compose<flute, flute, flute> music3;
	music3.compose_music();
	return 0;
}