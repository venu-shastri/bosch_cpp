#include<iostream>
using namespace std;

//illustration of 'this' pointer and its significance
// The 'this' pointer is a hidden formal parameter for a class member function.
class CA
{
private:
	int a,b;
public:
	void input()          // void input(CA* const this)
	{
		cout <<"enter 2 nos..." << endl;
		cin >> this->a >> this->b;
	}
	
	void print()           // void print(CA* const this)
	{
		cout <<"a:" << this->a <<",b:" << this->b << endl;
	}
};

//--- consumer code----
int main()
{
	CA obj1;
	obj1.input();       // CA::input(&obj1);
	obj1.print();       // CA::print(&obj1);
	return 0;
}
