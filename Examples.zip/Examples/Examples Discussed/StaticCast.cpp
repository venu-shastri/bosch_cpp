#include<iostream>
using namespace std;

//An example on static_cast

class CA
{
public:
	void fun1(){cout <<"CA fun1 called"<<endl; }
};

//class CB
class CB:public CA
{
public:
	void fun2(){cout <<"CB fun2 called"<<endl; }
};

int main()
{
	CA* p = new(nothrow) CA;
	p->fun1();
	
	CB* q = static_cast<CB*>(p);     //downcasting
	q->fun2();
	
	p = static_cast<CA*>(q);   //upcasting
	p->fun1();
	delete p;
	return 0;
}