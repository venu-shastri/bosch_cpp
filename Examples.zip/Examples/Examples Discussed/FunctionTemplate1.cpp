#include<iostream>
using namespace std;

//An example on generic function or template, supporting a single unknown datatype.

template<typename T> void Add(T x, T y)
{
	cout <<"sum:" << x+y << endl;
}

//---consumer code-----

int main()
{
	Add(10,20);
	Add(45.12f, 67.32f);
	Add(99.92, 33.9234);
	return 0;
}