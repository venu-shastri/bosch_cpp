#include<iostream>
using namespace std;

//An example class member function pointer

class CA
{
public:
	void fun1(){cout <<"CA fun1 called" << endl;}
	void fun2(){cout <<"CA fun2 called" << endl; }
};

int main()
{
	//declare a function pointer to hold the address of 
	//class CA member functions, of the form 'return type void and input-type void'
	void(CA::*fp)() = &CA::fun1;
	CA obj1;
	(obj1.*fp)();
	//***********************
	fp = &CA::fun2;
	CA* p = new(nothrow) CA;
	(p->*fp)();
	delete p;
	return 0;
}