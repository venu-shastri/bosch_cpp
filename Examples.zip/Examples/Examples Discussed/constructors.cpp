#include<iostream>
using namespace std;

//Introduce a constructor method, so as to place desired values into the object's data
//as when they get created or constructed.
class CA
{
private:
	int a,b;
public:
	CA();
	CA(int);
	CA(int, int);
	~CA();
	void input();
	void print();
};

//place the function definitions outside the class scope...
CA::CA()
{
	cout <<"CA default constructor called" << this << endl;
	this->a = 0;
	this->b = 0;
}
CA::CA(int x)
{
	cout <<"CA one arg. constructor" << this<< endl;
	this->a = x;
	this->b = x;
}
CA::CA(int x, int y)
{
	cout <<"CA two arg. constructor" << this<< endl;
	this->a = x;
	this->b = y;
}
CA::~CA(){cout <<"CA destructor" << this << endl; }

void CA::input()          // void input(CA* const this)
{
	cout <<"enter 2 nos..." << endl;
	cin >> this->a >> this->b;
}

void CA::print()           // void print(CA* const this)
{
	cout <<"a:" << this->a <<",b:" << this->b << endl;
}
//--- consumer code----
int main()
{
	CA obj1,obj2(100),obj3(30,40);
	
	obj1.print();       // CA::print(&obj1);
	obj2.print();
	obj3.print();
	return 0;
}
