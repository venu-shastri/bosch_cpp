#include<iostream>
using namespace std;
//an example on Generic class or class template, supporting a single unknown-datatype...

template<typename T=double> class CA   // 'double' is the default type
{
private:
	T a, b;
public:
	CA(T);
	CA(T, T);
	~CA();
	void Sum();
};
//place the definitions outside the class body
template<typename T>CA<T>::CA(T x) :a(x), b(x)
{
	cout << "CA<" << typeid(T).name() << "> one arg. constructor" << endl;
}
template<typename T>CA<T>::CA(T x, T y) : a(x), b(y)
{
	cout << "CA<" << typeid(T).name() << "> two arg. constructor" << endl;
}
template<typename T>CA<T>::~CA()
{
	cout << "CA<" << typeid(T).name() << ">::~CA() Destructor.." << endl;
}

template<typename T>void CA<T>::Sum()
{
	cout << "CA<" << typeid(T).name() << "> Sum=" << a+b << endl;
}

//Specialize the complete generic class CA for CHAR TYPE
template<> class CA<char>
{
private:
	char a,b;
public:
	//Definitions of a specialized class member function must be inside the class scope...
	CA(char x, char y):a(x),b(y)
	{
		cout <<"CA-char, specialized constructor" << endl;
	}
	~CA(){cout <<"CA-char, specialized destructor" << endl; }
	void print() const {cout <<"The 2 characters are :" << a <<", and " << b << endl; }
};
//**************consumer code ************************
int main()
{
	CA<int> obj1(10, 20);
	obj1.Sum();
	cout << "-------------" << endl;
	CA<float> obj2(56.12f, 63.89f);
	obj2.Sum();
	cout << "-------------" << endl;
	CA<> obj3(98.34, 79.56);    // CA<double> obj3(98.34, 79.56);
	obj3.Sum();
	cout << "-------------" << endl;
	CA<char> obj4('r','t');
	//obj4.Sum();
	obj4.print();
	return 0;
}