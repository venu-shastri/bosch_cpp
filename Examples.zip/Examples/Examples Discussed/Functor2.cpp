#include<iostream>
#include<list>
#include<algorithm>
using namespace std;

class CA
{
private:
	int a, b;
public:
	CA(int x = 0, int y = 0) :a(x), b(y) {  }
	CA(const CA& x) :a(x.a), b(x.b) { }
	~CA() {  }
	void print() const { cout << "CA-print, a:" << a << ",b:" << b << endl; }
    //FUNCTOR - The only member function of a class that can map to an algorithm in STL
	void operator()(CA& x) { cout << "CA_FUNCTOR, a:" << x.a << ",b:" << x.b << endl; }
};

void Print(CA& ob)
{
	ob.print();
}

//***consumer code*****
int main()
{
	list<CA> ls1;
	//populate the list with 5 CA objects
	for (int i = 1; i <= 5; i++)
	{
		ls1.push_back(CA(i, i + 10));
	}
	//iterate the list container
	/*
	list<CA>::iterator itr = ls1.begin();
	while (itr != ls1.end())
	{
		itr->print();
		itr++;
	}
	*/
	
	//for_each(ls1.begin(), ls1.end(), Print);  //bit expensive
	CA obj1;  
	for_each(ls1.begin(), ls1.end(),obj1);
                                  //,obj1.operator()(object_From_ls1));
	
	return 0;
}