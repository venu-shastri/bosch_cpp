#include<iostream>
using namespace std;

class Resource1
{
private:
	//..
public:
	void fun1() { cout << "Resource1 fun1() called" << endl; }
	void fun2() { cout << "Resource1 fun2() called" << endl; }
	void fun3() { cout << "Resource1 fun3() called" << endl; }
	void fun5() { cout << "Resource1 fun5() called" << endl; }
};

class Resource2
{
private:
	//..
public:
	void fun4() { cout << "Resource2 fun4() called" << endl; }
	void fun5() { cout << "Resource2 fun5() called" << endl; }
	void fun6() { cout << "Resource2 fun6() called" << endl; }
};

//****Smartpointer class*****
class Resource_Handler
{
private:
	Resource2* p;          //PIMPL model
public:
	Resource_Handler()	{	p = new(nothrow) Resource2;  	}
	~Resource_Handler() { delete p; }
	
	//void fun1() { p->fun1(); }
	//void fun2() { p->fun2(); }
	//void fun3() { p->fun3(); }
	
	//No need wrapper functions
	Resource2* operator ->()
	{
		return p;
	}
};

//****consumer code****
int main()
{
	
	Resource_Handler obj1;
	//obj1.fun1();
	//obj1.fun2();
	//obj1.fun3();
	//obj1->fun1();
	//obj1->fun2();
	//obj1->fun3();
	//obj1->fun5();
	obj1->fun4();
	return 0;
}