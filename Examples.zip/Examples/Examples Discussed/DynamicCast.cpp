#include<iostream>
using namespace std;

//An example on dynamic_cast, this operator only works on polymorphic class objects

class shape
{
public:
	virtual void draw() = 0;
};
class circle :public shape
{
public:
	void draw() { }
};
class rectangle :public shape
{
public:
	void draw() { }
};

void FindShape(shape* x)
{
	//circle* c = static_cast<circle*>(x);
	//rectangle* r = static_cast<rectangle*>(x);
	circle* c = dynamic_cast<circle*>(x);
	rectangle* r = dynamic_cast<rectangle*>(x);
	if (c != NULL)
		cout << "The object is circle.." << endl;
	if (r != NULL)
		cout << "The object is rectangle..." << endl;
}

//*****consumer code******
int main()
{
	circle* c = new(nothrow) circle;
	FindShape(c);
	delete c;
	return 0;
}