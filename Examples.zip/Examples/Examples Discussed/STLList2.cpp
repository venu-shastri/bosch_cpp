#include<iostream>
#include<list>
using namespace std;

int main()
{
	list<int> ls1;
	cout << "initial size of the list:" << ls1.size() << endl;
	//populate the list...
	for (int i = 1; i <= 10; i++)
		ls1.push_front(i);
	cout << "size of the list after pushing..." << ls1.size() << endl;
	//create an iterator object to traverse the list holding integers and let
	//the iterator object point to the first-node in the list.
	list<int>::iterator itr = ls1.begin();
	//now traverse the list
	cout << "contents of the list..." << endl;
	while (itr != ls1.end())
	{
		cout << *itr << " ";    // cout << itr.operator *() << " ";
		itr++;                  // itr.operator ++(int);
	}
	//sort the values in the list
	ls1.sort();
	cout <<"contents of the list after sorting.." << endl;
	itr = ls1.begin();
	while (itr != ls1.end())
	{
		cout << *itr << " ";    // cout << itr.operator *() << " ";
		itr++;                  // itr.operator ++(int);
	}
}