#include<iostream>
using namespace std;

class CA //assumed to be memory expensive
{
private:
	int a, b;
public:
	CA(int x = 0, int y = 0) :a(x), b(y) { cout << "CA constructor" << endl; }
	~CA() { cout << "CA destructor" << endl; }
	void print() const { cout << "CA-print, a:" << a << ",b:" << b << endl; }
};

class CB //assumed to be memory expensive
{
private:
	int a, b;
public:
	CB(int x = 0, int y = 0) :a(x), b(y) { cout << "CB constructor" << endl; }
	~CB() { cout << "CB destructor" << endl; }
	void Display() const { cout << "CB-Display, a:" << a << ",b:" << b << endl; }
};

//****Smartpointer class, Allocation is consumer choice, But de-allocation should be
//    the responsibility of the Smartpointer class.

template<typename T> class Smartpointer
{
private:
	T* p;
public:
	Smartpointer() :p(NULL) { }
	Smartpointer(T* x) :p(x) { }
	~Smartpointer()
	{
		if (p != NULL)
			delete p;
	}
	void operator = (T* x)
	{
		if ((this->p) == NULL)
			this->p = x;
		else
		{
			delete p;
			this->p = x;
		}
	}

	Smartpointer& operator = (Smartpointer& x)  //in-complete, check for other conditions...
	{
		if (this != &x)  //check for self-assignment
		{
			*(this->p) = *(x.p);
		}
	}

	Smartpointer(const Smartpointer& x)
	{
		p = new(nothrow) T(*(x.p));
	}
	T* operator ->() { return p; }
	T& operator *() { return *p; }
	operator bool()
	{
		if (p != NULL)
			return true;
		else
			return false;
	}
};

//****consumer-code******
int main()
{
	Smartpointer<CA> s1 = new(nothrow)CA(10, 20);
	s1->print();
	cout << "--------------------" << endl;
	Smartpointer<CB> s2 = new(nothrow) CB(30, 40);
	s2->Display();
	return 0;
}