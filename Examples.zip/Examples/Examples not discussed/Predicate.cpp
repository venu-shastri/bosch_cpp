#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

class Ascending
{
public:
	bool operator()(int &x, int &y)   //A functor whose return type is 'bool' is also called a predicate function
	{
		if(x < y)
			return true;
		else
			return false;
	}
};
class Descending
{
public:
	bool operator()(int &x, int &y)
	{
		if(x > y)
			return true;
		else
			return false;
	}
};

class Output
{
public:
	void operator()(int& x) { cout << x << endl; }
};

void main()
{
	Ascending obj1;
	Descending obj2;
	vector<int> v1;
	for(int i=1;i<=10;i++)
		v1.push_back(i);

	//vector<int>::iterator itr = v1.begin();
	cout <<endl << "contents of the vector after sorting in ascending"<<endl;
	sort(v1.begin(), v1.end(), obj1);
	/*while(itr != v1.end())
	{
		cout << *itr <<",";
		itr ++;
	}*/
	Output print;
	for_each(v1.begin(), v1.end(), print);
	sort(v1.begin(), v1.end(), obj2);
	cout <<endl << "contents of the vector after sorting in descending"<<endl;
	/*itr = v1.begin();
	while(itr != v1.end())
	{
		cout << *itr <<",";
		itr ++;
	}*/
	for_each(v1.begin(), v1.end(), print);
}