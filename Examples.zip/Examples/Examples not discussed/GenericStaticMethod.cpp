#include<iostream>
using namespace std;

//An example on generic class and static data/method.

template<typename T> class CA
{
private:
	T a;
	static int b;
public:
	CA(T x);
	void print() const;
	static void count();
};
//define memory for the static data
template<typename T> int CA<T>::b;

template<typename T> CA<T>::CA(T x) :a(x){	b = b + 1; }
template<typename T> void CA<T>::print() const { cout << "a:" << a << ",b:" << b << endl; }
template<typename T> void CA<T>::count() { cout << "objects of type<" << typeid(T).name() << "> =" << b << endl; }
//****consumer code****
int main()
{
	CA<int> obj1(100), obj2(200);
	CA<float> obj3(67.43f);
	CA<double> obj4(67.90), obj5(98.41), obj6(78.39);
	CA<int>::count();
	CA<float>::count();
	CA<double>::count();
	return 0;
}