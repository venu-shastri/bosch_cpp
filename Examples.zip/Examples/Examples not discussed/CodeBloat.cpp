#include<iostream>
using namespace std;

//An example on CODE BLOAT-situation where the compiler is un-necessarily forced to 
//     instantiate or generate duplicate code, which could be better avoided.

template<typename T> class Bloat
{
private:
	T a, b;    //generic data
	int c, d;  //non-generic data
public:
	Bloat(T x, T y, int e, int f) :a(x), b(y), c(e), d(f) { }
	void PrintAll()
	{
		cout << __FUNCDNAME__ << endl;
		cout << "PrintAll() called" << endl;
		cout << "Business on Generic info..., a=" << a << ",and b=" << b << endl;
		cout << "Business on Non-Generic info.., c=" << c << ", and d=" << d << endl;
	}
	void PrintInt()
	{
		cout << __FUNCDNAME__ << endl;
		cout << "PrintInt() called" << endl;
		cout << "Business on Non-Generic info.., c=" << c << ", and d=" << d << endl;
	}
};

//****consumer code*************
int main()
{
	Bloat<int> b1(100, 200, 30, 40);
	Bloat<float> b2(45.12f, 67.32f, 50, 60);
	b1.PrintAll();
	b1.PrintInt();
	b2.PrintAll();
	b2.PrintInt();
	return 0;
}