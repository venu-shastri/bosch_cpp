#include<iostream>
#include<new>
using namespace std;

class CA
{
public:
	CA() 	{	cout<<"CA created"<<endl; 	}
	void fun() 	{	cout<<"fun executed"<<endl;	}
	~CA(){	cout<<"CA destroyed"<<endl; 	}
};
//----------------------------------
class Ptr
{
private:
	CA*  m_p;
	int* m_c;
public:
	//******* constructors *******************

	Ptr():m_p(0),m_c(0){cout <<"Ptr default constr." <<endl;}					//default

	Ptr(CA* p):m_p(p),m_c(new int(1)) 
	{cout <<"Ptr overload constr." <<endl;}		//overloaded

	Ptr(Ptr& rhs):m_p(rhs.m_p),m_c(rhs.m_c)			//copy
	{ 
		cout <<"Ptr copy constr." <<endl;
		if(m_c)	
			++(*m_c); 
	}	
	//******* destructor *******************
	~Ptr()													//dest
	{
		cout <<"Ptr destr." <<endl;
		if((m_c) && (--(*m_c) == 0))
		{
			delete m_p;
			delete m_c;
		}
	}
	//******* = operators *******************
	Ptr& operator=(CA* p)									//= operator
	{
		this->Ptr::~Ptr();	//free existing memory
		this->Ptr::Ptr(p);	//overloaded
		return *this;		//always returns *this

	}
	Ptr& operator=(Ptr& rhs)
	{
		if(this == &rhs)		//check for self assignment
			return *this;

		this->Ptr::~Ptr();		//free existing memory
		this->Ptr::Ptr(rhs);  	//copy
		return *this;			//always returns *this
	}
	//******* operators *******************
	CA* operator->()
	{
		return m_p;
	}
};
//----------------------------------


void DoJob(Ptr p2)
{
	p2->fun();
}

int main()
{
	Ptr p1 (new CA());
	DoJob(p1);
	return 0;
}