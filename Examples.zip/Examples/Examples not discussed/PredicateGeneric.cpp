#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

template<typename T> class Ascending
{
public:
	bool operator()(T &x, T &y)
	{
		if(x < y)
			return true;
		else
			return false;
	}
};
template<typename T>class Descending
{
public:
	bool operator()(T &x, T &y)
	{
		if(x > y)
			return true;
		else
			return false;
	}
};

void main()
{
	Ascending<int> obj1;
	Descending<int> obj2;
	vector<int> v1;
	for(int i=1;i<=10;i++)
		v1.push_back(i);
	vector<int>::iterator itr = v1.begin();
	cout <<endl << "contents of the vector after sorting in ascending"<<endl;
	sort(v1.begin(), v1.end(), obj1);
	while(itr != v1.end())
	{
		cout << *itr <<",";
		itr ++;
	}
	sort(v1.begin(), v1.end(), obj2);
	cout <<endl << "contents of the vector after sorting in descending"<<endl;
	itr = v1.begin();
	while(itr != v1.end())
	{
		cout << *itr <<",";
		itr ++;
	}
}