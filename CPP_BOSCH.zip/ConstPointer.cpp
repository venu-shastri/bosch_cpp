#include<iostream>
using namespace std;

//usage of the extended qualifier 'const' with a pointer variable

int main()
{
	//   ELEMENT-1
	int a=100;
	//   ELEMENT-2
	int b=200;
	//   ELEMENT-3
	const int* p = &a;     // 'p' is a Pointer to a READ-ONLY integer.
	
	//Operations permitted on ELEMENT-3  'p'
	cout << *p << endl;    // 1. It's address can be read
	p = &b;                // 2. It's address content can be modified (write)
	cout << *p << endl;
	//Operation that is NOT permitted on ELEMENT-3 'p'
	*p = 300;   //Trying to modify the value pointed to by 'p'
	return 0;
}