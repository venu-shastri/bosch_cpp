#include<iostream>
using namespace std;

void Add(int=1, int=1);  //default arguments to be provided for declaration only

//void Add();
//void Add(int);
//---Add consumer
int main()
{
	Add();    
	Add(100);  
	Add(10,20);
	return 0;
}

void Add(int x, int y)
{
	cout <<x <<"+" << y <<"=" << x+y << endl;
}