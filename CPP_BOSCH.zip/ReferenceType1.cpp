#include<iostream>
using namespace std;

//An illustration of reference types [aliases]

int main()
{
	int a=100;
	//declare a reference type that shall act as an alias to 'a'
	int& ref = a;
	cout <<"---------------------" << endl;
	cout <<"Value of a:" << a <<",its address:-" << &a << endl;
	cout <<"---------------------" << endl;
	cout <<"Value of ref:" << ref <<",its address:-" << &ref << endl;
	
	a=a+100;
	cout <<"After change, a:" << a <<", and ref:" << ref << endl;
	return 0;
}