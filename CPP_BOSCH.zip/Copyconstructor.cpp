#include<iostream>
using namespace std;

//An example on copy constructor, Constructor method that takes a single parameter of its own kind
//by reference.
class CA
{
private:
	int a,b;
public:
	CA();
	CA(int);
	CA(int, int);
	CA(CA&);
	~CA();
	void input();
	void print();
};

//place the function definitions outside the class scope...
CA::CA():a(0),b(0)   //initialization list
{
	cout <<"CA default constructor called" << this << endl;
}
CA::CA(int x):a(x),b(x)
{
	cout <<"CA one arg. constructor" << this<< endl;
}
CA::CA(int x, int y):a(x),b(y)
{
	cout <<"CA two arg. constructor" << this<< endl;
}
CA::~CA(){cout <<"CA destructor" << this << endl; }

CA::CA(CA &x):a(x.a),b(x.b)
{ cout <<"CA copy constructor" << endl; }

void CA::input()          // void input(CA* const this)
{
	cout <<"enter 2 nos..." << endl;
	cin >> this->a >> this->b;
}

void CA::print()           // void print(CA* const this)
{
	cout <<"a:" << this->a <<",b:" << this->b << endl;
}
//--- consumer code----
int main()
{
	CA obj1(30,40);
	
	//CA obj2(obj1);   //1. calls copy constructor
	
	//-- Prefer the above copy constructor implementation as 
	//   it is more efficient when compared to the foll: approach
	
	CA obj2;               //1. calls default constructor
	obj2 = obj1;           //2. calls compiler generated assignment function
	
	obj1.print();       
	obj2.print();
	return 0;
}
