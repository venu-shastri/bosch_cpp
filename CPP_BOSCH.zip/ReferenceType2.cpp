#include<iostream>
using namespace std;

//A practical use-case for reference types.. EXTENDING SCOPE of a local variable

void swap1(int*, int*);
void swap2(int&, int&);

int main()
{
	int a=100,b=200;
	//swap1(&a, &b);
	swap2(a,b);
	cout <<"after swap, a:" << a <<",b:"<< b << endl;
	return 0;
}

void swap1(int* p, int* q)  // int* p = &a;   int* q = &b;   CALL BY ADDRESS
{
	int temp = *p;
	*p = *q;
	*q = temp;
}

void swap2(int& p, int& q)  // int& p = a;  int& q =b;   CALL BY REFERENCE
{
	int temp = p;
	p = q;
	q = temp;
}


