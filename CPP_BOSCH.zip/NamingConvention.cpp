#include<iostream>
using namespace std;

//An example on NAMING CONVENTION....

//extern "C++" void fun()     // fun.a   --> __Z3funv
extern "C" void fun()    //C naming convention, do not decorate
{cout <<"fun()   called" << endl;}

int main()
{
	fun();
	return 0;
}