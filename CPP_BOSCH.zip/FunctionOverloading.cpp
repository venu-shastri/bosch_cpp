#include<iostream>
using namespace std;

//An example on function overloading, where one or more functions can take the
//same name, subject to the formal parameters are unique.

void fun()
{cout <<"fun()   called" << endl;}

void fun(int x)
{cout <<"fun(int x)  called" << endl; }

void fun(float x, double y)
{cout <<"fun(float x, double y) called" << endl; }

//****consumer code******
int main()
{
	fun();
	fun(100);
	fun(45.12f, 89.76);
	return 0;
}
