#include<iostream>
using namespace std;

//An example on const objects, const methods and const correctness
class CA
{
private:
	int a,b;
public:
	CA();
	explicit CA(int);
	CA(int, int);
	CA(const CA&);
	~CA();
	void input();
	void print() const;
};

//place the function definitions outside the class scope...
CA::CA():a(0),b(0)   //initialization list
{
	cout <<"CA default constructor called" << this << endl;
}
//Constructors that take a single parameter as input are also called CONVERSION constructors.
CA::CA(int x):a(x),b(x)  
{
	cout <<"CA one arg. constructor" << this<< endl;
}
CA::CA(int x, int y):a(x),b(y)
{
	cout <<"CA two arg. constructor" << this<< endl;
}
CA::~CA(){cout <<"CA destructor" << this << endl; }

CA::CA(const CA &x):a(x.a),b(x.b)
{ cout <<"CA copy constructor" << endl; }

void CA::input()          // void input(CA* const this)
{
	cout <<"enter 2 nos..." << endl;
	cin >> this->a >> this->b;
}

void CA::print() const          // void print(const CA* const this)
{
	cout <<"a:" << this->a <<",b:" << this->b << endl;
}
//--- consumer code----
int main()
{
	//--context 1 ----
	CA obj1(20,30);   //READ-WRITE object
	obj1.print();    //READ OPERATION
	//..
	obj1.input();    //WRITE OPERATION
	obj1.print();
	
	//context 2----
	const CA obj2(30,40);  //READ-ONLY object
	//obj2.input();
	obj2.print();
	cout <<"--------------" << endl;
	CA obj3(obj2);  //demands copy constructor
	return 0;
}




