#include<iostream>
using namespace std;

void Add(int, int);

int main()
{
	Add(10,20);
	return 0;
}

inline void Add(int x, int y)
{
	//cout <<"sum:" << x+y << endl;
	cout << x <<"+" << y <<"=" << x+y << endl;
	cout <<"difference is:" << x-y << endl;
	//cout <<"product is:" << x*y << endl;
}