#include<iostream>
#include<typeinfo>
using namespace std;

int main()
{
	cout <<"raw name for char:" << typeid(char).name() << endl;
	cout <<"raw name for int:" << typeid(int).name() << endl;
	cout <<"raw name for float:" << typeid(float).name() << endl;
	cout <<"raw name for double:" << typeid(double).name() << endl;
	cout <<"raw name for bool:" << typeid(bool).name() << endl;
	cout <<"raw name for void:" << typeid(void).name() << endl;
	
	/*  In Visual studio IDE/compiler replace 'name' with raw_name'
	cout <<"raw name for char:" << typeid(char).raw_name() << endl;
	*/
	return 0;
}